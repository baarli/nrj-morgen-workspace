        // Supabase Config
        const SUPABASE_URL = 'https://kvniauxokdtmpvjtfnej.supabase.co';
        const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt2bmlhdXhva2R0bXB2anRmbmVqIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc1MTM2NzIzNCwiZXhwIjoyMDY2OTQzMjM0fQ.OkhTtq9QAQ3xMzZYKyWyCjj7PiqMZJKSvpA0jcBJqpE';
        const TENANT_ID = 'a0000000-0000-0000-0000-000000000001';
        const CREATED_BY = '10aa1508-6d52-490c-8ae5-fa3da9a152c4';
        
        let saker = [];
        let editingId = null;
        let previewId = null;
        let selectedIds = new Set();
        let sortable = null;

        // Initialize
        document.addEventListener('DOMContentLoaded', () => {
            loadSaker();
            initSortable();
            setupKeyboardShortcuts();
        });

        // ==================== DATA LOADING ====================
        
        async function loadSaker() {
            showNotification('Laster saker...', 'info');
            
            try {
                const today = new Date().toISOString().split('T')[0];
                const response = await fetch(
                    `${SUPABASE_URL}/rest/v1/agenda_items?tenant_id=eq.${TENANT_ID}&show_date=eq.${today}&order=order_index.asc`,
                    {
                        headers: {
                            'apikey': SUPABASE_KEY,
                            'Authorization': `Bearer ${SUPABASE_KEY}`
                        }
                    }
                );
                
                if (!response.ok) throw new Error('Failed to load');
                
                saker = await response.json();
                renderSaker();
                updateStats();
                showNotification(`Lastet ${saker.length} saker`, 'success');
            } catch (error) {
                console.error('Error loading saker:', error);
                showNotification('Kunne ikke laste saker', 'error');
            }
        }

        function renderSaker() {
            const container = document.getElementById('saker-list');
            
            if (saker.length === 0) {
                container.innerHTML = `
                    <div class="empty-state">
                        <i class="fas fa-newspaper"></i>
                        <h3>Ingen saker i dag</h3>
                        <p>Start med å kjøre Morning Routine eller legg til saker manuelt.</p>
                        <button class="btn btn-primary" onclick="runMorningRoutine()">
                            <i class="fas fa-play"></i> Kjør Morning Routine
                        </button>
                    </div>
                `;
                return;
            }
            
            container.innerHTML = saker.map((sak, index) => {
                const time = new Date(sak.created_at).toLocaleTimeString('nb-NO', {hour: '2-digit', minute: '2-digit'});
                const categoryClass = `badge-${sak.category?.toLowerCase() || 'talk'}`;
                const source = sak.link_url ? extractDomain(sak.link_url) : 'Ingen kilde';
                const isSelected = selectedIds.has(sak.id);
                const imageUrl = sak.link_metadata?.image_url || sak.image_url;
                
                return `
                    <div class="sak-item ${isSelected ? 'selected' : ''}" data-id="${sak.id}">
                        <div class="sak-checkbox">
                            <input type="checkbox" ${isSelected ? 'checked' : ''} onchange="toggleSelection('${sak.id}')">
                        </div>
                        <div class="sak-drag" title="Dra for å endre rekkefølge">
                            <i class="fas fa-grip-vertical"></i>
                        </div>
                        
                        <div class="sak-info">
                            <h4>${escapeHtml(sak.title)}</h4>
                            <p>${escapeHtml(sak.description || '').substring(0, 120)}${(sak.description || '').length > 120 ? '...' : ''}</p>
                            <div class="sak-meta">
                                <span><i class="fas fa-link"></i> ${source}</span>
                                ${imageUrl ? '<span><i class="fas fa-image"></i> Bilde</span>' : ''}
                            </div>
                        </div>
                        
                        <div class="sak-category">
                            <span class="badge ${categoryClass}">${sak.category || 'TALK'}</span>
                        </div>
                        
                        <div class="sak-time">${time}</div>
                        
                        <div class="sak-actions">
                            <button class="preview" onclick="previewSak('${sak.id}')" title="Forhåndsvis (P)"><i class="fas fa-eye"></i></button>
                            <button class="edit" onclick="editSak('${sak.id}')" title="Rediger (E)"><i class="fas fa-edit"></i></button>
                            <button class="delete" onclick="deleteSak('${sak.id}')" title="Slett (Del)"><i class="fas fa-trash"></i></button>
                        </div>
                    </div>
                `;
            }).join('');
        }

        function updateStats() {
            document.getElementById('stat-count').textContent = saker.length;
            document.getElementById('stat-updated').textContent = new Date().toLocaleTimeString('nb-NO', {hour: '2-digit', minute: '2-digit'});
        }

        // ==================== SORTABLE (DRAG & DROP) ====================
        
        function initSortable() {
            const container = document.getElementById('saker-list');
            
            sortable = new Sortable(container, {
                handle: '.sak-drag',
                animation: 150,
                ghostClass: 'dragging',
                onEnd: async (evt) => {
                    const itemEl = evt.item;
                    const newIndex = evt.newIndex;
                    const sakId = itemEl.getAttribute('data-id');
                    
                    // Update order in database
                    await updateSakOrder(sakId, newIndex + 1);
                    
                    // Reload to get correct order
                    loadSaker();
                }
            });
        }

        async function updateSakOrder(sakId, newOrder) {
            try {
                const response = await fetch(`${SUPABASE_URL}/rest/v1/agenda_items?id=eq.${sakId}`, {
                    method: 'PATCH',
                    headers: {
                        'apikey': SUPABASE_KEY,
                        'Authorization': `Bearer ${SUPABASE_KEY}`,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ order_index: newOrder })
                });
                
                if (!response.ok) throw new Error('Failed to update order');
            } catch (error) {
                console.error('Error updating order:', error);
            }
        }

        // ==================== SELECTION & BULK ACTIONS ====================
        
        function toggleSelection(id) {
            if (selectedIds.has(id)) {
                selectedIds.delete(id);
            } else {
                selectedIds.add(id);
            }
            
            updateBulkActions();
            renderSaker();
        }
        
        function toggleSelectAllVisible() {
            const checkboxes = document.querySelectorAll('.sak-checkbox input[type="checkbox"]');
            const allChecked = Array.from(checkboxes).every(cb => cb.checked);
            
            if (allChecked) {
                selectedIds.clear();
            } else {
                saker.forEach(sak => selectedIds.add(sak.id));
            }
            
            updateBulkActions();
            renderSaker();
        }
        
        function toggleSelectAll() {
            toggleSelectAllVisible();
        }
        
        function updateBulkActions() {
            const bulkActions = document.getElementById('bulk-actions');
            const countEl = document.getElementById('selected-count');
            
            if (selectedIds.size > 0) {
                bulkActions.classList.add('active');
                countEl.textContent = selectedIds.size;
            } else {
                bulkActions.classList.remove('active');
            }
        }
        
        function clearSelection() {
            selectedIds.clear();
            updateBulkActions();
            renderSaker();
        }
        
        async function bulkDelete() {
            if (!confirm(`Slett ${selectedIds.size} valgte saker?`)) return;
            
            showNotification(`Sletter ${selectedIds.size} saker...`, 'warning');
            
            try {
                for (const id of selectedIds) {
                    await fetch(`${SUPABASE_URL}/rest/v1/agenda_items?id=eq.${id}`, {
                        method: 'DELETE',
                        headers: {
                            'apikey': SUPABASE_KEY,
                            'Authorization': `Bearer ${SUPABASE_KEY}`
                        }
                    });
                }
                
                selectedIds.clear();
                updateBulkActions();
                showNotification('Saker slettet', 'success');
                loadSaker();
            } catch (error) {
                showNotification('Kunne ikke slette saker', 'error');
            }
        }
        
        async function bulkCategory() {
            const newCategory = prompt('Ny kategori (TALK, MUSIC, NEWS, BREAKING):');
            if (!newCategory) return;
            
            showNotification(`Oppdaterer kategori for ${selectedIds.size} saker...`, 'warning');
            
            try {
                for (const id of selectedIds) {
                    await fetch(`${SUPABASE_URL}/rest/v1/agenda_items?id=eq.${id}`, {
                        method: 'PATCH',
                        headers: {
                            'apikey': SUPABASE_KEY,
                            'Authorization': `Bearer ${SUPABASE_KEY}`,
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ category: newCategory.toUpperCase() })
                    });
                }
                
                selectedIds.clear();
                updateBulkActions();
                showNotification('Kategori oppdatert', 'success');
                loadSaker();
            } catch (error) {
                showNotification('Kunne ikke oppdatere kategori', 'error');
            }
        }

        // ==================== FILTERING & SEARCH ====================
        
        function filterSaker() {
            const search = document.getElementById('search-input').value.toLowerCase();
            const category = document.getElementById('filter-category').value;
            const source = document.getElementById('filter-source').value;
            
            const items = document.querySelectorAll('.sak-item');
            let visibleCount = 0;
            
            items.forEach(item => {
                const id = item.getAttribute('data-id');
                const sak = saker.find(s => s.id === id);
                if (!sak) return;
                
                const matchesSearch = !search || 
                    sak.title.toLowerCase().includes(search) || 
                    (sak.description || '').toLowerCase().includes(search) ||
                    (sak.notes || '').toLowerCase().includes(search);
                    
                const matchesCategory = !category || sak.category === category;
                const matchesSource = !source || (sak.link_url && sak.link_url.toLowerCase().includes(source.toLowerCase()));
                
                const isVisible = matchesSearch && matchesCategory && matchesSource;
                item.style.display = isVisible ? '' : 'none';
                if (isVisible) visibleCount++;
            });
            
            // Update count display
            if (search || category || source) {
                document.getElementById('stat-count').textContent = `${visibleCount}/${saker.length}`;
            } else {
                document.getElementById('stat-count').textContent = saker.length;
            }
        }

        // ==================== MODALS ====================
        
        function openAddModal() {
            editingId = null;
            document.getElementById('edit-modal-title').textContent = 'Legg til Sak';
            clearForm();
            document.getElementById('sak-order').value = saker.length + 1;
            document.getElementById('edit-modal').classList.add('active');
            document.getElementById('sak-title').focus();
        }
        
        async function editSak(id) {
            const sak = saker.find(s => s.id === id);
            if (!sak) return;
            
            editingId = id;
            document.getElementById('edit-modal-title').textContent = 'Rediger Sak';
            
            document.getElementById('sak-id').value = id;
            document.getElementById('sak-title').value = sak.title || '';
            document.getElementById('sak-description').value = sak.description || '';
            document.getElementById('sak-category').value = sak.category || 'TALK';
            document.getElementById('sak-source').value = extractSourceFromNotes(sak.notes) || 'VG';
            document.getElementById('sak-order').value = sak.order_index || 1;
            document.getElementById('sak-url').value = sak.link_url || '';
            document.getElementById('sak-notes').value = sak.notes || '';
            document.getElementById('sak-image').value = sak.link_metadata?.image_url || sak.image_url || '';
            
            updateImagePreview();
            document.getElementById('edit-modal').classList.add('active');
            document.getElementById('sak-title').focus();
        }
        
        function closeEditModal() {
            document.getElementById('edit-modal').classList.remove('active');
            editingId = null;
        }
        
        function previewSak(id) {
            const sak = saker.find(s => s.id === id);
            if (!sak) return;
            
            previewId = id;
            
            document.getElementById('preview-title').textContent = sak.title;
            document.getElementById('preview-description').textContent = sak.description || 'Ingen beskrivelse';
            document.getElementById('preview-notes').textContent = sak.notes || 'Ingen notater';
            document.getElementById('preview-category').textContent = sak.category || 'TALK';
            document.getElementById('preview-time').textContent = new Date(sak.created_at).toLocaleString('nb-NO');
            
            const linkEl = document.getElementById('preview-link');
            if (sak.link_url) {
                linkEl.href = sak.link_url;
                linkEl.style.display = '';
            } else {
                linkEl.style.display = 'none';
            }
            
            const imageEl = document.getElementById('preview-image');
            const imageUrl = sak.link_metadata?.image_url || sak.image_url;
            if (imageUrl) {
                imageEl.src = imageUrl;
                imageEl.style.display = '';
            } else {
                imageEl.style.display = 'none';
            }
            
            document.getElementById('preview-modal').classList.add('active');
        }
        
        function closePreviewModal() {
            document.getElementById('preview-modal').classList.remove('active');
            previewId = null;
        }
        
        function editFromPreview() {
            closePreviewModal();
            if (previewId) {
                setTimeout(() => editSak(previewId), 100);
            }
        }

        // ==================== FORM HANDLING ====================
        
        function clearForm() {
            document.getElementById('sak-id').value = '';
            document.getElementById('sak-title').value = '';
            document.getElementById('sak-description').value = '';
            document.getElementById('sak-category').value = 'TALK';
            document.getElementById('sak-source').value = 'VG';
            document.getElementById('sak-order').value = '';
            document.getElementById('sak-url').value = '';
            document.getElementById('sak-notes').value = '';
            document.getElementById('sak-image').value = '';
            updateImagePreview();
        }
        
        function updateImagePreview() {
            const url = document.getElementById('sak-image').value;
            const preview = document.getElementById('image-preview');
            
            if (url) {
                preview.innerHTML = `<img src="${escapeHtml(url)}" alt="Preview" onerror="this.parentElement.innerHTML='<span class=\'placeholder\'>Kunne ikke laste bilde</span>'">`;
            } else {
                preview.innerHTML = '<span class="placeholder">Ingen bilde valgt</span>';
            }
        }
        
        async function saveSak() {
            const title = document.getElementById('sak-title').value.trim();
            const description = document.getElementById('sak-description').value.trim();
            const category = document.getElementById('sak-category').value;
            const source = document.getElementById('sak-source').value;
            const orderIndex = parseInt(document.getElementById('sak-order').value) || 1;
            const url = document.getElementById('sak-url').value.trim();
            const notes = document.getElementById('sak-notes').value.trim();
            const imageUrl = document.getElementById('sak-image').value.trim();
            
            if (!title) {
                showNotification('Tittel er påkrevd', 'error');
                document.getElementById('sak-title').focus();
                return;
            }
            
            const today = new Date().toISOString().split('T')[0];
            
            // Build notes if empty
            let finalNotes = notes;
            if (!finalNotes && description) {
                finalNotes = `${description.split('.')[0]}\n\nKilde: ${source}`;
            }
            
            const payload = {
                tenant_id: TENANT_ID,
                title: title,
                description: description,
                category: category,
                notes: finalNotes,
                link_url: url,
                show_date: today,
                created_by: CREATED_BY,
                order_index: orderIndex,
                link_metadata: imageUrl ? { image_url: imageUrl } : null
            };
            
            try {
                let response;
                if (editingId) {
                    response = await fetch(`${SUPABASE_URL}/rest/v1/agenda_items?id=eq.${editingId}`, {
                        method: 'PATCH',
                        headers: {
                            'apikey': SUPABASE_KEY,
                            'Authorization': `Bearer ${SUPABASE_KEY}`,
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(payload)
                    });
                } else {
                    response = await fetch(`${SUPABASE_URL}/rest/v1/agenda_items`, {
                        method: 'POST',
                        headers: {
                            'apikey': SUPABASE_KEY,
                            'Authorization': `Bearer ${SUPABASE_KEY}`,
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(payload)
                    });
                }
                
                if (!response.ok) throw new Error('Save failed');
                
                closeEditModal();
                showNotification(editingId ? 'Sak oppdatert!' : 'Sak lagt til!', 'success');
                loadSaker();
            } catch (error) {
                console.error('Error saving sak:', error);
                showNotification('Kunne ikke lagre sak', 'error');
            }
        }
        
        async function deleteSak(id) {
            if (!confirm('Er du sikker på at du vil slette denne saken?')) return;
            
            try {
                const response = await fetch(`${SUPABASE_URL}/rest/v1/agenda_items?id=eq.${id}`, {
                    method: 'DELETE',
                    headers: {
                        'apikey': SUPABASE_KEY,
                        'Authorization': `Bearer ${SUPABASE_KEY}`
                    }
                });
                
                if (!response.ok) throw new Error('Delete failed');
                
                showNotification('Sak slettet', 'success');
                loadSaker();
            } catch (error) {
                console.error('Error deleting sak:', error);
                showNotification('Kunne ikke slette sak', 'error');
            }
        }

        // ==================== MORNING ROUTINE ====================
        
        async function runMorningRoutine() {
            if (!confirm('Dette vil slette alle dagens saker og hente nye fra nettet. Fortsette?')) return;
            
            const btn = document.getElementById('btn-morning');
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Starter...';
            
            showNotification('Starter Morning Routine...', 'warning');
            showProgress(10);
            
            try {
                const response = await fetch('http://47.84.19.119:8081/api/routine/morning', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' }
                });
                
                if (!response.ok) throw new Error('Failed to start');
                
                const result = await response.json();
                
                if (result.status === 'already_running') {
                    showNotification('Morning Routine kjører allerede!', 'warning');
                } else {
                    showProgress(30);
                    pollRoutineProgress();
                }
            } catch (error) {
                console.error('Error starting routine:', error);
                showNotification('Kunne ikke starte Morning Routine', 'error');
                hideProgress();
            } finally {
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-play"></i> Kjør Morning Routine';
            }
        }
        
        async function pollRoutineProgress() {
            const checkProgress = async () => {
                try {
                    const response = await fetch('http://47.84.19.119:8081/api/routine/morning/status');
                    const status = await response.json();
                    
                    showProgress(status.progress);
                    
                    if (status.running) {
                        showNotification(`${status.message}`, 'info', 0);
                        setTimeout(checkProgress, 2000);
                    } else if (status.last_result) {
                        hideProgress();
                        if (status.last_result.error) {
                            showNotification(`Feil: ${status.last_result.error}`, 'error');
                        } else {
                            showNotification(`Fullført! ${status.last_result.count || 'Flere'} saker hentet.`, 'success');
                            loadSaker();
                        }
                    }
                } catch (error) {
                    console.error('Error checking progress:', error);
                    hideProgress();
                }
            };
            
            checkProgress();
        }
        
        function showProgress(percent) {
            const container = document.getElementById('progress-container');
            const bar = document.getElementById('progress-bar');
            container.classList.add('active');
            bar.style.width = `${percent}%`;
        }
        
        function hideProgress() {
            const container = document.getElementById('progress-container');
            const bar = document.getElementById('progress-bar');
            container.classList.remove('active');
            bar.style.width = '0%';
        }

        // ==================== EXPORT/IMPORT ====================
        
        function exportSaker() {
            const data = {
                exported_at: new Date().toISOString(),
                count: saker.length,
                saker: saker
            };
            
            const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `nrj-saker-${new Date().toISOString().split('T')[0]}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            showNotification('Saker eksportert', 'success');
        }
        
        async function importSaker(input) {
            const file = input.files[0];
            if (!file) return;
            
            try {
                const text = await file.text();
                const data = JSON.parse(text);
                
                if (!data.saker || !Array.isArray(data.saker)) {
                    throw new Error('Invalid file format');
                }
                
                if (!confirm(`Importere ${data.saker.length} saker?`)) return;
                
                showNotification(`Importerer ${data.saker.length} saker...`, 'warning');
                
                const today = new Date().toISOString().split('T')[0];
                let imported = 0;
                
                for (const sak of data.saker) {
                    const payload = {
                        tenant_id: TENANT_ID,
                        title: sak.title,
                        description: sak.description,
                        category: sak.category || 'TALK',
                        notes: sak.notes,
                        link_url: sak.link_url,
                        show_date: today,
                        created_by: CREATED_BY,
                        order_index: saker.length + imported + 1,
                        link_metadata: sak.link_metadata
                    };
                    
                    const response = await fetch(`${SUPABASE_URL}/rest/v1/agenda_items`, {
                        method: 'POST',
                        headers: {
                            'apikey': SUPABASE_KEY,
                            'Authorization': `Bearer ${SUPABASE_KEY}`,
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(payload)
                    });
                    
                    if (response.ok) imported++;
                }
                
                showNotification(`${imported} saker importert!`, 'success');
                loadSaker();
            } catch (error) {
                console.error('Import error:', error);
                showNotification('Kunne ikke importere fil', 'error');
            }
            
            input.value = '';
        }

        // ==================== KEYBOARD SHORTCUTS ====================
        
        function setupKeyboardShortcuts() {
            document.addEventListener('keydown', (e) => {
                // Don't trigger if in input
                if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
                    if (e.key === 'Escape') {
                        closeEditModal();
                        closePreviewModal();
                    }
                    return;
                }
                
                switch(e.key.toLowerCase()) {
                    case 'n':
                        e.preventDefault();
                        openAddModal();
                        break;
                    case 'r':
                        e.preventDefault();
                        refreshSaker();
                        break;
                    case '/':
                        e.preventDefault();
                        document.getElementById('search-input').focus();
                        break;
                    case '?':
                        e.preventDefault();
                        toggleShortcutsHelp();
                        break;
                    case 'escape':
                        closeEditModal();
                        closePreviewModal();
                        clearSelection();
                        break;
                }
            });
        }
        
        function toggleShortcutsHelp() {
            const help = document.getElementById('shortcuts-help');
            help.classList.toggle('active');
        }

        // ==================== UTILITIES ====================
        
        function refreshSaker() {
            loadSaker();
        }
        
        function showStats() {
            showNotification('Statistikk kommer snart!', 'info');
        }
        
        function showConfig() {
            showNotification('Innstillinger kommer snart!', 'info');
        }
        
        function extractDomain(url) {
            try {
                return new URL(url).hostname.replace('www.', '').split('.')[0].toUpperCase();
            } catch {
                return 'Ukjent';
            }
        }
        
        function extractSourceFromNotes(notes) {
            if (!notes) return null;
            const match = notes.match(/Kilde:\s*(.+)/);
            return match ? match[1].trim() : null;
        }
        
        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        function showNotification(message, type = 'info', duration = 5000) {
            const container = document.getElementById('notification-container');
            
            const icons = {
                success: 'fa-check-circle',
                error: 'fa-exclamation-circle',
                warning: 'fa-exclamation-triangle',
                info: 'fa-info-circle'
            };
            
            const titles = {
                success: 'Suksess',
                error: 'Feil',
                warning: 'Varsel',
                info: 'Info'
            };
            
            const notif = document.createElement('div');
            notif.className = `notification ${type}`;
            notif.innerHTML = `
                <i class="fas ${icons[type]} notification-icon" style="color: var(--${type === 'info' ? 'primary' : type});"></i>
                <div class="notification-content">
                    <div class="notification-title">${titles[type]}</div>
                    <div class="notification-message">${message}</div>
                </div>
                <button class="notification-close" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>
            `;
            
            container.appendChild(notif);
            
            if (duration > 0) {
                setTimeout(() => {
                    notif.classList.add('hiding');
                    setTimeout(() => notif.remove(), 300);
                }, duration);
            }
            
            return notif;
        }
        
        // Close modals on overlay click
        document.getElementById('edit-modal').addEventListener('click', (e) => {
            if (e.target === document.getElementById('edit-modal')) closeEditModal();
        });
        
        document.getElementById('preview-modal').addEventListener('click', (e) => {
            if (e.target === document.getElementById('preview-modal')) closePreviewModal();
        });
